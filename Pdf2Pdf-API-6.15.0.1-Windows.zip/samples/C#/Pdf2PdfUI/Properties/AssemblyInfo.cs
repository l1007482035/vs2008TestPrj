﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("PDF to PDF/A Converter Sample")]
[assembly: AssemblyDescription("Author: Philip Renggli")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("PDF Tools AG (www.pdf-tools.com)")]
[assembly: AssemblyProduct("3-Heights(TM) PDF to PDF/A Converter API")]
[assembly: AssemblyCopyright("Copyright © PDF Tools AG 2008-2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("36d4c037-0f67-4e5b-92a7-c692fa3bf48c")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("6.15.0.0")]
[assembly: AssemblyFileVersion("6.15.0.1")]
